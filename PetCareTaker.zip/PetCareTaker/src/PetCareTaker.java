import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * PetCareBook - Pet Vaccination Reminder System (simple version).
 *
 * Everything is in this one file. Run the main() method of this class.
 * - Screens are built with Java Swing.
 * - Data is saved in plain text files inside the "data" folder (no database needed).
 *
 * Default admin login:  admin@petcarebook.com  /  Admin@123
 */
public class PetCareTaker {

    // =====================================================================
    //  1. CONSTANTS
    // =====================================================================

    static final String DATA_DIR = "data";
    static final String[] SPECIES = {"DOG", "CAT", "BIRD", "RABBIT", "HAMSTER", "OTHER"};
    static final String[] STATUSES = {"UPCOMING", "DUE_TODAY", "OVERDUE", "COMPLETED"};
    static final int UPCOMING_DAYS = 7;

    static final Color BG = new Color(232, 244, 250);
    static final Color DARK = new Color(24, 74, 94);
    static final Color TEAL = new Color(0, 150, 150);
    static final Color BLUE = new Color(52, 120, 190);
    static final Color RED = new Color(206, 60, 60);
    static final Color ORANGE = new Color(230, 150, 30);
    static final Color GRAY = new Color(110, 120, 130);

    // =====================================================================
    //  2. DATA CLASSES
    // =====================================================================

    static class Owner {
        int id;
        String name, email, phone, passwordHash, role; // role = USER or ADMIN
    }

    static class Pet {
        int id;
        String name, species, breed, gender, color, allergies, medicalNotes;
        LocalDate dateOfBirth;
        Double weight; // may be null
        int ownerId;
    }

    static class VaccineType {
        int id;
        String name, species, description;
        int intervalInDays;
    }

    static class Vaccination {
        int id, petId, typeId;
        LocalDate dateGiven, nextDueDate;
        String notes;
    }

    /** One line of a vaccination table: the record plus its pet, vaccine and calculated status. */
    static class Row {
        Vaccination vac;
        Pet pet;
        VaccineType type;
        String status;

        Row(Vaccination vac, Pet pet, VaccineType type, String status) {
            this.vac = vac;
            this.pet = pet;
            this.type = type;
            this.status = status;
        }
    }

    /** Thrown for any rule that is broken; the message is shown to the user. */
    static class AppException extends RuntimeException {
        AppException(String message) {
            super(message);
        }
    }

    // =====================================================================
    //  3. IN-MEMORY DATA (saved to text files)
    // =====================================================================

    static List<Owner> owners = new ArrayList<>();
    static List<Pet> pets = new ArrayList<>();
    static List<VaccineType> types = new ArrayList<>();
    static List<Vaccination> vaccinations = new ArrayList<>();
    static int ownerSeq = 1, petSeq = 1, typeSeq = 1, vacSeq = 1;

    static Owner currentUser; // the logged-in user

    // ---------- saving ----------

    static String clean(String s) {
        if (s == null) {
            return "";
        }
        return s.replace("|", " ").replace("\r", " ").replace("\n", " ");
    }

    static void saveAll() {
        List<String> lines = new ArrayList<>();
        for (Owner o : owners) {
            lines.add(o.id + "|" + clean(o.name) + "|" + clean(o.email) + "|" + clean(o.phone) + "|" + o.passwordHash + "|" + o.role);
        }
        writeFile("owners.txt", lines);

        lines = new ArrayList<>();
        for (Pet p : pets) {
            lines.add(p.id + "|" + clean(p.name) + "|" + p.species + "|" + clean(p.breed) + "|" + p.dateOfBirth + "|" + p.gender + "|"
                    + (p.weight == null ? "" : p.weight) + "|" + clean(p.color) + "|" + clean(p.allergies) + "|" + clean(p.medicalNotes) + "|" + p.ownerId);
        }
        writeFile("pets.txt", lines);

        lines = new ArrayList<>();
        for (VaccineType t : types) {
            lines.add(t.id + "|" + clean(t.name) + "|" + t.species + "|" + clean(t.description) + "|" + t.intervalInDays);
        }
        writeFile("vaccine_types.txt", lines);

        lines = new ArrayList<>();
        for (Vaccination v : vaccinations) {
            lines.add(v.id + "|" + v.petId + "|" + v.typeId + "|" + v.dateGiven + "|" + v.nextDueDate + "|" + clean(v.notes));
        }
        writeFile("vaccinations.txt", lines);
    }

    static void writeFile(String name, List<String> lines) {
        new File(DATA_DIR).mkdirs();
        try (PrintWriter out = new PrintWriter(new OutputStreamWriter(new FileOutputStream(new File(DATA_DIR, name)), StandardCharsets.UTF_8))) {
            for (String line : lines) {
                out.println(line);
            }
        } catch (IOException e) {
            System.out.println("Could not save " + name + ": " + e.getMessage());
        }
    }

    // ---------- loading ----------

    static List<String[]> readFile(String name) {
        List<String[]> rows = new ArrayList<>();
        File file = new File(DATA_DIR, name);
        if (!file.exists()) {
            return rows;
        }
        try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = in.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    rows.add(line.split("\\|", -1));
                }
            }
        } catch (IOException e) {
            System.out.println("Could not read " + name + ": " + e.getMessage());
        }
        return rows;
    }

    static void loadAll() {
        for (String[] f : readFile("owners.txt")) {
            Owner o = new Owner();
            o.id = Integer.parseInt(f[0]);
            o.name = f[1];
            o.email = f[2];
            o.phone = f[3];
            o.passwordHash = f[4];
            o.role = f[5];
            owners.add(o);
            ownerSeq = Math.max(ownerSeq, o.id + 1);
        }
        for (String[] f : readFile("pets.txt")) {
            Pet p = new Pet();
            p.id = Integer.parseInt(f[0]);
            p.name = f[1];
            p.species = f[2];
            p.breed = f[3];
            p.dateOfBirth = LocalDate.parse(f[4]);
            p.gender = f[5];
            p.weight = f[6].isEmpty() ? null : Double.valueOf(f[6]);
            p.color = f[7];
            p.allergies = f[8];
            p.medicalNotes = f[9];
            p.ownerId = Integer.parseInt(f[10]);
            pets.add(p);
            petSeq = Math.max(petSeq, p.id + 1);
        }
        for (String[] f : readFile("vaccine_types.txt")) {
            VaccineType t = new VaccineType();
            t.id = Integer.parseInt(f[0]);
            t.name = f[1];
            t.species = f[2];
            t.description = f[3];
            t.intervalInDays = Integer.parseInt(f[4]);
            types.add(t);
            typeSeq = Math.max(typeSeq, t.id + 1);
        }
        for (String[] f : readFile("vaccinations.txt")) {
            Vaccination v = new Vaccination();
            v.id = Integer.parseInt(f[0]);
            v.petId = Integer.parseInt(f[1]);
            v.typeId = Integer.parseInt(f[2]);
            v.dateGiven = LocalDate.parse(f[3]);
            v.nextDueDate = LocalDate.parse(f[4]);
            v.notes = f[5];
            vaccinations.add(v);
            vacSeq = Math.max(vacSeq, v.id + 1);
        }
    }

    // ---------- first-time data (default admin + vaccine types) ----------

    static void seedDefaults() {
        if (findOwnerByEmail("admin@petcarebook.com") == null) {
            Owner admin = new Owner();
            admin.id = ownerSeq++;
            admin.name = "PetCareBook Admin";
            admin.email = "admin@petcarebook.com";
            admin.phone = "9000000000";
            admin.passwordHash = hash("Admin@123");
            admin.role = "ADMIN";
            owners.add(admin);
        }
        if (types.isEmpty()) {
            seedType("Rabies", "DOG", "Protects against rabies virus", 365);
            seedType("DHPP", "DOG", "Distemper, hepatitis, parvovirus, parainfluenza", 365);
            seedType("Bordetella", "DOG", "Kennel cough protection", 180);
            seedType("Leptospirosis", "DOG", "Bacterial infection protection", 365);
            seedType("Deworming", "DOG", "Intestinal parasite control", 90);
            seedType("Rabies", "CAT", "Protects against rabies virus", 365);
            seedType("FVRCP", "CAT", "Rhinotracheitis, calicivirus, panleukopenia", 365);
            seedType("FeLV", "CAT", "Feline leukemia virus protection", 365);
            seedType("Deworming", "CAT", "Intestinal parasite control", 90);
            seedType("Myxomatosis", "RABBIT", "Protects against myxomatosis", 180);
            seedType("RHD", "RABBIT", "Rabbit haemorrhagic disease protection", 365);
            seedType("Polyomavirus", "BIRD", "Protects against avian polyomavirus", 365);
        }
        saveAll();
    }

    static void seedType(String name, String species, String description, int days) {
        VaccineType t = new VaccineType();
        t.id = typeSeq++;
        t.name = name;
        t.species = species;
        t.description = description;
        t.intervalInDays = days;
        types.add(t);
    }

    // =====================================================================
    //  4. BUSINESS LOGIC (rules, validation, status calculation)
    // =====================================================================

    static String hash(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // ---------- finders ----------

    static Owner findOwnerByEmail(String email) {
        for (Owner o : owners) {
            if (o.email.equalsIgnoreCase(email)) {
                return o;
            }
        }
        return null;
    }

    static Owner findOwner(int id) {
        for (Owner o : owners) {
            if (o.id == id) {
                return o;
            }
        }
        return null;
    }

    static Pet findPet(int id) {
        for (Pet p : pets) {
            if (p.id == id) {
                return p;
            }
        }
        return null;
    }

    static VaccineType findType(int id) {
        for (VaccineType t : types) {
            if (t.id == id) {
                return t;
            }
        }
        return null;
    }

    static List<Pet> petsOfOwner(int ownerId) {
        List<Pet> list = new ArrayList<>();
        for (Pet p : pets) {
            if (p.ownerId == ownerId) {
                list.add(p);
            }
        }
        Collections.sort(list, (a, b) -> a.name.compareToIgnoreCase(b.name));
        return list;
    }

    static List<VaccineType> sortedTypes() {
        List<VaccineType> list = new ArrayList<>(types);
        Collections.sort(list, (a, b) -> {
            int c = a.species.compareTo(b.species);
            return c != 0 ? c : a.name.compareToIgnoreCase(b.name);
        });
        return list;
    }

    static boolean petHasRecords(int petId) {
        for (Vaccination v : vaccinations) {
            if (v.petId == petId) {
                return true;
            }
        }
        return false;
    }

    static boolean typeIsUsed(int typeId) {
        for (Vaccination v : vaccinations) {
            if (v.typeId == typeId) {
                return true;
            }
        }
        return false;
    }

    static boolean has(String value, String query) {
        if (query == null || query.trim().isEmpty()) {
            return true;
        }
        return value != null && value.toLowerCase().contains(query.trim().toLowerCase());
    }

    static LocalDate parseDate(String text, String fieldName) {
        try {
            return LocalDate.parse(text.trim());
        } catch (DateTimeParseException e) {
            throw new AppException(fieldName + " must be a valid date in the format yyyy-MM-dd (example 2026-03-15)");
        }
    }

    static LocalDate tryDate(String text) {
        try {
            return text.trim().isEmpty() ? null : LocalDate.parse(text.trim());
        } catch (DateTimeParseException e) {
            return null;
        }
    }

    // ---------- accounts ----------

    static Owner register(String name, String email, String phone, String password, String confirm) {
        name = name.trim();
        email = email.trim().toLowerCase();
        phone = phone.trim();
        if (name.isEmpty()) {
            throw new AppException("Full name is required");
        }
        if (name.length() > 100) {
            throw new AppException("Name must be at most 100 characters");
        }
        if (email.isEmpty()) {
            throw new AppException("Email is required");
        }
        if (!email.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {
            throw new AppException("Email format is invalid");
        }
        if (phone.isEmpty()) {
            throw new AppException("Phone number is required");
        }
        if (!phone.matches("^[0-9+\\- ]{7,15}$")) {
            throw new AppException("Phone number must be 7 to 15 digits");
        }
        if (password.length() < 8 || password.length() > 64) {
            throw new AppException("Password must be 8 to 64 characters");
        }
        if (!password.equals(confirm)) {
            throw new AppException("Passwords do not match");
        }
        if (findOwnerByEmail(email) != null) {
            throw new AppException("An account with email " + email + " already exists");
        }
        Owner o = new Owner();
        o.id = ownerSeq++;
        o.name = name;
        o.email = email;
        o.phone = phone;
        o.passwordHash = hash(password);
        o.role = "USER";
        owners.add(o);
        saveAll();
        return o;
    }

    static Owner login(String email, String password) {
        Owner o = findOwnerByEmail(email.trim().toLowerCase());
        if (o == null || !o.passwordHash.equals(hash(password))) {
            throw new AppException("Invalid email or password");
        }
        return o;
    }

    static boolean isAdmin() {
        return currentUser != null && currentUser.role.equals("ADMIN");
    }

    // ---------- pets ----------

    static void savePet(Pet existing, String name, String species, String breed, String dobText, String gender,
                        String weightText, String color, String allergies, String notes) {
        name = name.trim();
        breed = breed.trim();
        if (name.isEmpty()) {
            throw new AppException("Pet name is required");
        }
        if (name.length() > 60) {
            throw new AppException("Pet name must be at most 60 characters");
        }
        if (breed.length() > 60) {
            throw new AppException("Breed must be at most 60 characters");
        }
        LocalDate dob = parseDate(dobText, "Date of birth");
        if (dob.isAfter(LocalDate.now())) {
            throw new AppException("Date of birth cannot be in the future");
        }
        Double weight = null;
        if (!weightText.trim().isEmpty()) {
            try {
                weight = Double.valueOf(weightText.trim());
            } catch (NumberFormatException e) {
                throw new AppException("Weight must be a number");
            }
            if (weight <= 0) {
                throw new AppException("Weight must be greater than zero");
            }
        }
        if (color.length() > 40) {
            throw new AppException("Color must be at most 40 characters");
        }
        if (allergies.length() > 500) {
            throw new AppException("Allergies must be at most 500 characters");
        }
        if (notes.length() > 1000) {
            throw new AppException("Medical notes must be at most 1000 characters");
        }
        if (existing != null && !existing.species.equals(species) && petHasRecords(existing.id)) {
            throw new AppException("Species cannot be changed for a pet that already has vaccination records");
        }

        Pet p = existing;
        if (p == null) {
            p = new Pet();
            p.id = petSeq++;
            p.ownerId = currentUser.id;
            pets.add(p);
        }
        p.name = name;
        p.species = species;
        p.breed = breed;
        p.dateOfBirth = dob;
        p.gender = gender;
        p.weight = weight;
        p.color = color.trim();
        p.allergies = allergies.trim();
        p.medicalNotes = notes.trim();
        saveAll();
    }

    /** Deletes the pet and all of its vaccination records. */
    static void deletePet(Pet pet) {
        vaccinations.removeIf(v -> v.petId == pet.id);
        pets.remove(pet);
        saveAll();
    }

    // ---------- vaccination status ----------

    /** For every pet + vaccine type, only the newest record is "active"; older ones are COMPLETED. */
    static Set<Integer> latestIds(List<Vaccination> list) {
        Map<String, Vaccination> latest = new HashMap<>();
        for (Vaccination v : list) {
            String key = v.petId + ":" + v.typeId;
            Vaccination current = latest.get(key);
            if (current == null || v.dateGiven.isAfter(current.dateGiven)
                    || (v.dateGiven.isEqual(current.dateGiven) && v.id > current.id)) {
                latest.put(key, v);
            }
        }
        Set<Integer> ids = new HashSet<>();
        for (Vaccination v : latest.values()) {
            ids.add(v.id);
        }
        return ids;
    }

    static String statusOf(Vaccination v, Set<Integer> latestIds, LocalDate today) {
        if (!latestIds.contains(v.id)) {
            return "COMPLETED";
        }
        if (v.nextDueDate.isBefore(today)) {
            return "OVERDUE";
        }
        if (v.nextDueDate.isEqual(today)) {
            return "DUE_TODAY";
        }
        if (!v.nextDueDate.isAfter(today.plusDays(UPCOMING_DAYS))) {
            return "UPCOMING";
        }
        return "COMPLETED";
    }

    /** Overall status shown for a pet: NO_RECORDS, OVERDUE, DUE_TODAY, UPCOMING or UP_TO_DATE. */
    static String petStatus(int petId) {
        List<Vaccination> list = new ArrayList<>();
        for (Vaccination v : vaccinations) {
            if (v.petId == petId) {
                list.add(v);
            }
        }
        if (list.isEmpty()) {
            return "NO_RECORDS";
        }
        Set<Integer> latest = latestIds(list);
        LocalDate today = LocalDate.now();
        boolean overdue = false, dueToday = false, upcoming = false;
        for (Vaccination v : list) {
            String s = statusOf(v, latest, today);
            if (s.equals("OVERDUE")) overdue = true;
            if (s.equals("DUE_TODAY")) dueToday = true;
            if (s.equals("UPCOMING")) upcoming = true;
        }
        if (overdue) return "OVERDUE";
        if (dueToday) return "DUE_TODAY";
        if (upcoming) return "UPCOMING";
        return "UP_TO_DATE";
    }

    // ---------- vaccinations ----------

    /** Search this owner's vaccination records. Use petId = -1 and null values for "no filter". */
    static List<Row> search(int ownerId, int petId, String petName, String species, String breed, String vaccine,
                            String status, LocalDate from, LocalDate to) {
        List<Vaccination> mine = new ArrayList<>();
        for (Vaccination v : vaccinations) {
            Pet p = findPet(v.petId);
            if (p != null && p.ownerId == ownerId) {
                mine.add(v);
            }
        }
        Collections.sort(mine, (a, b) -> {
            int c = b.dateGiven.compareTo(a.dateGiven);
            return c != 0 ? c : b.id - a.id;
        });
        Set<Integer> latest = latestIds(mine);
        LocalDate today = LocalDate.now();

        List<Row> result = new ArrayList<>();
        for (Vaccination v : mine) {
            Pet p = findPet(v.petId);
            VaccineType t = findType(v.typeId);
            String s = statusOf(v, latest, today);
            if (petId != -1 && p.id != petId) continue;
            if (!has(p.name, petName)) continue;
            if (species != null && !p.species.equals(species)) continue;
            if (!has(p.breed, breed)) continue;
            if (!has(t.name, vaccine)) continue;
            if (from != null && v.dateGiven.isBefore(from)) continue;
            if (to != null && v.dateGiven.isAfter(to)) continue;
            if (status != null && !s.equals(status)) continue;
            result.add(new Row(v, p, t, s));
        }
        return result;
    }

    static List<Row> byStatus(String status) {
        List<Row> list = search(currentUser.id, -1, null, null, null, null, status, null, null);
        Collections.sort(list, (a, b) -> a.vac.nextDueDate.compareTo(b.vac.nextDueDate));
        return list;
    }

    static void addVaccination(Pet pet, VaccineType type, String dateText, String notes) {
        if (pet == null) {
            throw new AppException("Please select a pet");
        }
        if (type == null) {
            throw new AppException("Please select a vaccine");
        }
        LocalDate date = parseDate(dateText, "Vaccination date");
        if (!type.species.equals(pet.species)) {
            throw new AppException("Vaccine '" + type.name + "' is intended for " + type.species + " but " + pet.name + " is a " + pet.species);
        }
        if (date.isAfter(LocalDate.now())) {
            throw new AppException("Vaccination date cannot be in the future");
        }
        if (date.isBefore(pet.dateOfBirth)) {
            throw new AppException("Vaccination date cannot be before the pet's date of birth");
        }
        if (notes.length() > 500) {
            throw new AppException("Notes must be at most 500 characters");
        }
        for (Vaccination v : vaccinations) {
            if (v.petId == pet.id && v.typeId == type.id && v.dateGiven.isEqual(date)) {
                throw new AppException(type.name + " is already recorded for " + pet.name + " on " + date);
            }
        }
        Vaccination v = new Vaccination();
        v.id = vacSeq++;
        v.petId = pet.id;
        v.typeId = type.id;
        v.dateGiven = date;
        v.nextDueDate = date.plusDays(type.intervalInDays);
        v.notes = notes.trim();
        vaccinations.add(v);
        saveAll();
    }

    // ---------- vaccine types ----------

    static boolean typeNameExists(String name, String species) {
        for (VaccineType t : types) {
            if (t.name.equalsIgnoreCase(name) && t.species.equals(species)) {
                return true;
            }
        }
        return false;
    }

    static void saveType(VaccineType existing, String name, String species, String description, String intervalText) {
        name = name.trim();
        if (name.isEmpty()) {
            throw new AppException("Vaccine name is required");
        }
        if (name.length() > 100) {
            throw new AppException("Vaccine name must be at most 100 characters");
        }
        if (description.length() > 500) {
            throw new AppException("Description must be at most 500 characters");
        }
        int interval;
        try {
            interval = Integer.parseInt(intervalText.trim());
        } catch (NumberFormatException e) {
            throw new AppException("Interval in days must be a whole number");
        }
        if (interval < 1) {
            throw new AppException("Interval must be at least 1 day");
        }
        if (interval > 3650) {
            throw new AppException("Interval must be at most 3650 days");
        }
        boolean identityChanged = existing == null || !existing.name.equalsIgnoreCase(name) || !existing.species.equals(species);
        if (identityChanged && typeNameExists(name, species)) {
            throw new AppException("Vaccine '" + name + "' already exists for " + species);
        }
        if (existing != null && !existing.species.equals(species) && typeIsUsed(existing.id)) {
            throw new AppException("Species cannot be changed for a vaccine type that is already used in vaccination records");
        }
        VaccineType t = existing;
        if (t == null) {
            t = new VaccineType();
            t.id = typeSeq++;
            types.add(t);
        }
        t.name = name;
        t.species = species;
        t.description = description.trim();
        t.intervalInDays = interval;
        saveAll();
    }

    static void deleteType(VaccineType t) {
        if (typeIsUsed(t.id)) {
            throw new AppException("Vaccine type is used in vaccination records and cannot be deleted");
        }
        types.remove(t);
        saveAll();
    }

    // ---------- admin ----------

    static void deleteUser(Owner o) {
        if (o.id == currentUser.id) {
            throw new AppException("You cannot delete your own account");
        }
        for (Pet p : petsOfOwner(o.id)) {
            deletePet(p);
        }
        owners.remove(o);
        saveAll();
    }

    // ---------- reminders (replaces the daily scheduler of the old project) ----------

    /** Prints reminders for every owner to the console when the program starts. */
    static void printReminders() {
        LocalDate today = LocalDate.now();
        Set<Integer> latest = latestIds(vaccinations);
        for (Vaccination v : vaccinations) {
            boolean inWindow = !v.nextDueDate.isBefore(today) && !v.nextDueDate.isAfter(today.plusDays(UPCOMING_DAYS));
            if (latest.contains(v.id) && inWindow) {
                Pet p = findPet(v.petId);
                Owner o = findOwner(p.ownerId);
                System.out.println("REMINDER: " + p.name + " (" + p.species + ") needs " + findType(v.typeId).name
                        + " on " + v.nextDueDate + " - owner " + o.name + " <" + o.email + ">");
            }
        }
    }

    /** Short text shown in a pop-up after login. Empty when nothing needs attention. */
    static String reminderSummary() {
        int overdue = byStatus("OVERDUE").size();
        int dueToday = byStatus("DUE_TODAY").size();
        int upcoming = byStatus("UPCOMING").size();
        if (overdue + dueToday + upcoming == 0) {
            return "";
        }
        return "Vaccination reminders:\n\n  Overdue: " + overdue + "\n  Due today: " + dueToday
                + "\n  Due in the next " + UPCOMING_DAYS + " days: " + upcoming + "\n\nSee the Reminders page for details.";
    }

    // =====================================================================
    //  5. SCREEN HELPERS
    // =====================================================================

    static JFrame frame;
    static JPanel content; // right side of the main screen

    static void error(String message) {
        JOptionPane.showMessageDialog(frame, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    static void info(String message) {
        JOptionPane.showMessageDialog(frame, message, "PetCareBook", JOptionPane.INFORMATION_MESSAGE);
    }

    static boolean confirm(String message) {
        return JOptionPane.showConfirmDialog(frame, message, "Please confirm", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }

    static void setScreen(JPanel panel) {
        frame.setContentPane(panel);
        frame.revalidate();
        frame.repaint();
    }

    static JButton button(String text, Color color, ActionListener action) {
        JButton b = new JButton(text);
        b.setBackground(color);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setFont(new Font("SansSerif", Font.BOLD, 13));
        b.addActionListener(action);
        return b;
    }

    static JLabel heading(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("SansSerif", Font.BOLD, 24));
        l.setForeground(DARK);
        return l;
    }

    static JLabel bold(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("SansSerif", Font.BOLD, 14));
        l.setForeground(DARK);
        return l;
    }

    /** A blank page with the light-blue background. */
    static JPanel newPage() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBackground(BG);
        p.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        return p;
    }

    static JPanel vbox() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setOpaque(false);
        return p;
    }

    static void addLeft(JPanel box, JComponent c) {
        c.setAlignmentX(Component.LEFT_ALIGNMENT);
        box.add(c);
    }

    /** A left-aligned row of components. */
    static JPanel row(Component... items) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        p.setOpaque(false);
        for (Component c : items) {
            p.add(c);
        }
        return p;
    }

    /** A white box with a title border. */
    static JPanel card(String title) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createTitledBorder(title));
        return p;
    }

    static JPanel statCard(String label, int value, Color color) {
        JPanel p = new JPanel(new GridLayout(2, 1));
        p.setBackground(color);
        p.setBorder(BorderFactory.createEmptyBorder(12, 15, 12, 15));
        JLabel number = new JLabel(String.valueOf(value));
        number.setFont(new Font("SansSerif", Font.BOLD, 30));
        number.setForeground(Color.WHITE);
        JLabel text = new JLabel(label);
        text.setForeground(Color.WHITE);
        p.add(number);
        p.add(text);
        return p;
    }

    static JComboBox<String> combo(String firstItem, String[] items) {
        JComboBox<String> box = new JComboBox<>();
        box.addItem(firstItem);
        for (String s : items) {
            box.addItem(s);
        }
        return box;
    }

    /** Returns the chosen item, or null when the first ("All ...") item is selected. */
    static String picked(JComboBox<String> box) {
        return box.getSelectedIndex() <= 0 ? null : (String) box.getSelectedItem();
    }

    static void onChange(JTextField field, Runnable action) {
        field.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { action.run(); }
            public void removeUpdate(DocumentEvent e) { action.run(); }
            public void changedUpdate(DocumentEvent e) { action.run(); }
        });
    }

    static void formRow(JPanel p, int row, String label, JComponent field) {
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5, 5, 5, 5);
        g.gridy = row;
        g.anchor = GridBagConstraints.WEST;
        g.gridx = 0;
        p.add(new JLabel(label), g);
        g.gridx = 1;
        g.fill = GridBagConstraints.HORIZONTAL;
        g.weightx = 1;
        p.add(field, g);
    }

    static void formSpan(JPanel p, int row, JComponent c) {
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 5, 6, 5);
        g.gridy = row;
        g.gridx = 0;
        g.gridwidth = 2;
        g.fill = GridBagConstraints.HORIZONTAL;
        p.add(c, g);
    }

    // ---------- tables ----------

    static String statusLabel(String status) {
        return status.replace('_', ' ');
    }

    static Color statusColor(String text) {
        String s = text.replace(' ', '_');
        if (s.equals("OVERDUE")) return new Color(255, 205, 205);
        if (s.equals("DUE_TODAY")) return new Color(255, 228, 170);
        if (s.equals("UPCOMING")) return new Color(255, 245, 180);
        if (s.equals("COMPLETED") || s.equals("UP_TO_DATE")) return new Color(208, 240, 214);
        if (s.equals("NO_RECORDS")) return new Color(225, 225, 225);
        return null;
    }

    /** Colors any cell that contains a status word. */
    static class StatusRenderer extends DefaultTableCellRenderer {
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int r, int c) {
            Component comp = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, r, c);
            if (!isSelected) {
                comp.setBackground(Color.WHITE);
                Color color = value == null ? null : statusColor(value.toString());
                if (color != null) {
                    comp.setBackground(color);
                }
            }
            return comp;
        }
    }

    static DefaultTableModel model(String... columns) {
        return new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }

    static JTable table(DefaultTableModel model) {
        JTable t = new JTable(model);
        t.setRowHeight(26);
        t.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        t.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 13));
        t.setDefaultRenderer(Object.class, new StatusRenderer());
        return t;
    }

    /** Returns the selected row, or -1 (after showing a message) when nothing is selected. */
    static int selectedRow(JTable t) {
        int r = t.getSelectedRow();
        if (r < 0) {
            error("Please select a row in the table first.");
        }
        return r;
    }

    // =====================================================================
    //  6. LOGIN AND REGISTER SCREENS
    // =====================================================================

    static void showLogin() {
        JPanel bg = new JPanel(new GridBagLayout());
        bg.setBackground(BG);

        JPanel box = new JPanel(new GridBagLayout());
        box.setBackground(Color.WHITE);
        box.setBorder(BorderFactory.createEmptyBorder(25, 35, 25, 35));

        JTextField email = new JTextField(20);
        JPasswordField password = new JPasswordField(20);
        ActionListener doLogin = e -> {
            try {
                currentUser = login(email.getText(), new String(password.getPassword()));
                showMain();
            } catch (AppException ex) {
                error(ex.getMessage());
            }
        };
        password.addActionListener(doLogin);

        JLabel title = heading("PetCareBook");
        JLabel sub = new JLabel("Sign in to keep your pets protected");
        JLabel hint = new JLabel("Default admin: admin@petcarebook.com / Admin@123");
        hint.setForeground(GRAY);
        hint.setFont(new Font("SansSerif", Font.PLAIN, 11));

        formSpan(box, 0, title);
        formSpan(box, 1, sub);
        formRow(box, 2, "Email", email);
        formRow(box, 3, "Password", password);
        formSpan(box, 4, button("Login", TEAL, doLogin));
        formSpan(box, 5, button("Create a new account", BLUE, e -> showRegister()));
        formSpan(box, 6, hint);

        bg.add(box);
        setScreen(bg);
    }

    static void showRegister() {
        JPanel bg = new JPanel(new GridBagLayout());
        bg.setBackground(BG);

        JPanel box = new JPanel(new GridBagLayout());
        box.setBackground(Color.WHITE);
        box.setBorder(BorderFactory.createEmptyBorder(25, 35, 25, 35));

        JTextField name = new JTextField(20);
        JTextField email = new JTextField(20);
        JTextField phone = new JTextField(20);
        JPasswordField password = new JPasswordField(20);
        JPasswordField confirm = new JPasswordField(20);

        ActionListener doRegister = e -> {
            try {
                currentUser = register(name.getText(), email.getText(), phone.getText(),
                        new String(password.getPassword()), new String(confirm.getPassword()));
                showMain();
            } catch (AppException ex) {
                error(ex.getMessage());
            }
        };
        confirm.addActionListener(doRegister);

        formSpan(box, 0, heading("Create your account"));
        formRow(box, 1, "Full name", name);
        formRow(box, 2, "Email", email);
        formRow(box, 3, "Phone number", phone);
        formRow(box, 4, "Password", password);
        formRow(box, 5, "Confirm password", confirm);
        formSpan(box, 6, button("Register", TEAL, doRegister));
        formSpan(box, 7, button("Back to login", GRAY, e -> showLogin()));

        bg.add(box);
        setScreen(bg);
    }

    // =====================================================================
    //  7. MAIN SCREEN (sidebar + pages)
    // =====================================================================

    static void showMain() {
        JPanel root = new JPanel(new BorderLayout());

        JPanel side = new JPanel();
        side.setLayout(new BoxLayout(side, BoxLayout.Y_AXIS));
        side.setBackground(DARK);
        side.setPreferredSize(new Dimension(190, 0));
        side.setBorder(BorderFactory.createEmptyBorder(15, 10, 15, 10));

        JLabel logo = new JLabel("PetCareBook");
        logo.setFont(new Font("SansSerif", Font.BOLD, 20));
        logo.setForeground(Color.WHITE);
        JLabel who = new JLabel(currentUser.name);
        who.setForeground(new Color(190, 220, 230));
        addLeft(side, logo);
        addLeft(side, who);
        side.add(Box.createVerticalStrut(20));

        List<String> pages = new ArrayList<>();
        pages.add("Home");
        pages.add("My Pets");
        pages.add("Vaccinations");
        pages.add("Reminders");
        pages.add("Vaccine Types");
        pages.add("Profile");
        if (isAdmin()) {
            pages.add("Admin");
        }
        for (String name : pages) {
            JButton b = button(name, new Color(40, 100, 125), e -> go(name));
            b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
            addLeft(side, b);
            side.add(Box.createVerticalStrut(6));
        }
        side.add(Box.createVerticalGlue());
        JButton logout = button("Logout", RED, e -> {
            currentUser = null;
            showLogin();
        });
        logout.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        addLeft(side, logout);

        content = new JPanel(new BorderLayout());
        root.add(side, BorderLayout.WEST);
        root.add(content, BorderLayout.CENTER);
        setScreen(root);
        go("Home");

        String summary = reminderSummary();
        if (!summary.isEmpty()) {
            info(summary);
        }
    }

    /** Shows one page on the right side. Pages are rebuilt each time so they always show fresh data. */
    static void go(String page) {
        JPanel p;
        if (page.equals("Home")) p = homePage();
        else if (page.equals("My Pets")) p = petsPage();
        else if (page.equals("Vaccinations")) p = vaccinationsPage();
        else if (page.equals("Reminders")) p = remindersPage();
        else if (page.equals("Vaccine Types")) p = vaccineTypesPage();
        else if (page.equals("Profile")) p = profilePage();
        else p = adminPage();
        content.removeAll();
        content.add(p, BorderLayout.CENTER);
        content.revalidate();
        content.repaint();
    }

    // =====================================================================
    //  8. HOME (dashboard)
    // =====================================================================

    static JPanel homePage() {
        JPanel page = newPage();
        List<Row> all = search(currentUser.id, -1, null, null, null, null, null, null, null);
        int dueToday = 0, upcoming = 0, overdue = 0;
        for (Row r : all) {
            if (r.status.equals("DUE_TODAY")) dueToday++;
            if (r.status.equals("UPCOMING")) upcoming++;
            if (r.status.equals("OVERDUE")) overdue++;
        }
        upcoming += dueToday; // "upcoming" also counts what is due today

        JPanel top = vbox();
        addLeft(top, heading("Welcome to PetCareBook, " + currentUser.name));
        addLeft(top, new JLabel("Keep your pets healthy, happy and protected."));
        addLeft(top, row(
                button("Add a pet", TEAL, e -> {
                    if (petDialog(null)) {
                        go("My Pets");
                    }
                }),
                button("Record vaccination", BLUE, e -> go("Vaccinations"))));
        JPanel stats = new JPanel(new GridLayout(1, 4, 12, 0));
        stats.setOpaque(false);
        stats.add(statCard("Total Pets", petsOfOwner(currentUser.id).size(), BLUE));
        stats.add(statCard("Total Vaccinations", all.size(), TEAL));
        stats.add(statCard("Upcoming (7 days)", upcoming, ORANGE));
        stats.add(statCard("Overdue", overdue, RED));
        top.add(Box.createVerticalStrut(10));
        addLeft(top, stats);
        top.add(Box.createVerticalStrut(10));
        addLeft(top, bold("Needs attention (next 5)"));

        // next 5 records that need attention, earliest due date first
        List<Row> attention = new ArrayList<>();
        for (Row r : all) {
            if (r.status.equals("OVERDUE") || r.status.equals("DUE_TODAY") || r.status.equals("UPCOMING")) {
                attention.add(r);
            }
        }
        Collections.sort(attention, (a, b) -> a.vac.nextDueDate.compareTo(b.vac.nextDueDate));
        DefaultTableModel m = model("Pet", "Vaccine", "Next Due Date", "Status");
        for (int i = 0; i < attention.size() && i < 5; i++) {
            Row r = attention.get(i);
            m.addRow(new Object[]{r.pet.name, r.type.name, r.vac.nextDueDate, statusLabel(r.status)});
        }
        page.add(top, BorderLayout.NORTH);
        if (attention.isEmpty()) {
            JLabel ok = new JLabel("All caught up. No vaccinations need attention right now.");
            ok.setFont(new Font("SansSerif", Font.PLAIN, 15));
            page.add(ok, BorderLayout.CENTER);
        } else {
            page.add(new JScrollPane(table(m)), BorderLayout.CENTER);
        }
        return page;
    }

    // =====================================================================
    //  9. MY PETS
    // =====================================================================

    static JPanel petsPage() {
        JPanel page = newPage();
        JTextField search = new JTextField(14);
        JTextField breed = new JTextField(12);
        JComboBox<String> species = combo("All species", SPECIES);
        DefaultTableModel m = model("Name", "Species", "Breed", "Born", "Gender", "Owner", "Vaccination Status");
        JTable t = table(m);
        List<Pet> shown = new ArrayList<>();

        Runnable refresh = () -> {
            m.setRowCount(0);
            shown.clear();
            for (Pet p : petsOfOwner(currentUser.id)) {
                if (!has(p.name, search.getText())) continue;
                if (picked(species) != null && !p.species.equals(picked(species))) continue;
                if (!has(p.breed, breed.getText())) continue;
                shown.add(p);
                m.addRow(new Object[]{p.name, p.species, p.breed.isEmpty() ? "-" : p.breed, p.dateOfBirth, p.gender,
                        currentUser.name, statusLabel(petStatus(p.id))});
            }
        };
        onChange(search, refresh);
        onChange(breed, refresh);
        species.addActionListener(e -> refresh.run());
        refresh.run();

        JPanel top = vbox();
        addLeft(top, heading("My Pets"));
        addLeft(top, row(new JLabel("Search name:"), search, new JLabel("Species:"), species, new JLabel("Breed:"), breed));
        page.add(top, BorderLayout.NORTH);
        page.add(new JScrollPane(t), BorderLayout.CENTER);

        JPanel buttons = row(
                button("+ Add New Pet", TEAL, e -> {
                    if (petDialog(null)) refresh.run();
                }),
                button("View Profile", BLUE, e -> {
                    int r = selectedRow(t);
                    if (r >= 0) petProfileDialog(shown.get(r));
                }),
                button("Vaccination History", BLUE, e -> {
                    int r = selectedRow(t);
                    if (r >= 0) historyDialog(shown.get(r));
                }),
                button("Edit", ORANGE, e -> {
                    int r = selectedRow(t);
                    if (r >= 0 && petDialog(shown.get(r))) refresh.run();
                }),
                button("Delete", RED, e -> {
                    int r = selectedRow(t);
                    if (r < 0) return;
                    Pet p = shown.get(r);
                    if (confirm("Delete " + p.name + " and all of their vaccination records?")) {
                        deletePet(p);
                        refresh.run();
                    }
                }));
        page.add(buttons, BorderLayout.SOUTH);
        return page;
    }

    /** Add (existing == null) or edit a pet. Returns true when saved. */
    static boolean petDialog(Pet existing) {
        JTextField name = new JTextField(existing == null ? "" : existing.name, 20);
        JComboBox<String> species = new JComboBox<>(SPECIES);
        JTextField breed = new JTextField(existing == null ? "" : existing.breed, 20);
        JTextField dob = new JTextField(existing == null ? "" : existing.dateOfBirth.toString(), 20);
        JComboBox<String> gender = new JComboBox<>(new String[]{"MALE", "FEMALE"});
        JTextField weight = new JTextField(existing == null || existing.weight == null ? "" : existing.weight.toString(), 20);
        JTextField color = new JTextField(existing == null ? "" : existing.color, 20);
        JTextField allergies = new JTextField(existing == null ? "" : existing.allergies, 20);
        JTextArea notes = new JTextArea(existing == null ? "" : existing.medicalNotes, 3, 20);
        notes.setLineWrap(true);
        if (existing != null) {
            species.setSelectedItem(existing.species);
            gender.setSelectedItem(existing.gender);
        }

        JPanel form = new JPanel(new GridBagLayout());
        formRow(form, 0, "Pet name", name);
        formRow(form, 1, "Species", species);
        formRow(form, 2, "Breed", breed);
        formRow(form, 3, "Date of birth (yyyy-MM-dd)", dob);
        formRow(form, 4, "Gender", gender);
        formRow(form, 5, "Weight (kg)", weight);
        formRow(form, 6, "Color", color);
        formRow(form, 7, "Allergies", allergies);
        formRow(form, 8, "Medical notes", new JScrollPane(notes));

        while (true) {
            int choice = JOptionPane.showConfirmDialog(frame, form, existing == null ? "Add New Pet" : "Edit Pet",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (choice != JOptionPane.OK_OPTION) {
                return false;
            }
            try {
                savePet(existing, name.getText(), (String) species.getSelectedItem(), breed.getText(), dob.getText(),
                        (String) gender.getSelectedItem(), weight.getText(), color.getText(), allergies.getText(), notes.getText());
                return true;
            } catch (AppException ex) {
                error(ex.getMessage()); // the form opens again with your values
            }
        }
    }

    static void petProfileDialog(Pet p) {
        String text = "Name:  " + p.name
                + "\nVaccination status:  " + statusLabel(petStatus(p.id))
                + "\nSpecies:  " + p.species
                + "\nBreed:  " + (p.breed.isEmpty() ? "-" : p.breed)
                + "\nDate of birth:  " + p.dateOfBirth
                + "\nGender:  " + p.gender
                + "\nWeight:  " + (p.weight == null ? "-" : p.weight + " kg")
                + "\nColor:  " + (p.color.isEmpty() ? "-" : p.color)
                + "\nAllergies:  " + (p.allergies.isEmpty() ? "-" : p.allergies)
                + "\nMedical notes:  " + (p.medicalNotes.isEmpty() ? "-" : p.medicalNotes)
                + "\nOwner:  " + findOwner(p.ownerId).name;
        JTextArea area = new JTextArea(text);
        area.setEditable(false);
        area.setBackground(BG);
        area.setFont(new Font("SansSerif", Font.PLAIN, 14));
        area.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        JOptionPane.showMessageDialog(frame, area, "Pet Profile - " + p.name, JOptionPane.PLAIN_MESSAGE);
    }

    static void historyDialog(Pet pet) {
        List<Row> rows = search(currentUser.id, pet.id, null, null, null, null, null, null, null);
        if (rows.isEmpty()) {
            info("No vaccinations recorded yet for " + pet.name + ".");
            return;
        }
        DefaultTableModel m = model("Vaccine", "Date Given", "Next Due Date", "Status", "Notes");
        for (Row r : rows) {
            m.addRow(new Object[]{r.type.name, r.vac.dateGiven, r.vac.nextDueDate, statusLabel(r.status), r.vac.notes});
        }
        JScrollPane scroll = new JScrollPane(table(m));
        scroll.setPreferredSize(new Dimension(650, 260));
        JOptionPane.showMessageDialog(frame, scroll, "Vaccination History - " + pet.name, JOptionPane.PLAIN_MESSAGE);
    }

    // =====================================================================
    //  10. VACCINATIONS
    // =====================================================================

    static JPanel vaccinationsPage() {
        JPanel page = newPage();
        List<Pet> myPets = petsOfOwner(currentUser.id);

        // ----- record form -----
        JComboBox<String> petBox = new JComboBox<>();
        petBox.addItem("Select pet");
        for (Pet p : myPets) {
            petBox.addItem(p.name + " (" + p.species + ")");
        }
        JComboBox<String> typeBox = new JComboBox<>();
        List<VaccineType> availableTypes = new ArrayList<>();
        JTextField date = new JTextField(LocalDate.now().toString(), 10);
        JLabel nextDue = new JLabel("Calculated automatically");
        JTextField notes = new JTextField(22);

        Runnable updateNextDue = () -> {
            int i = typeBox.getSelectedIndex();
            if (i <= 0 || i > availableTypes.size()) {
                nextDue.setText("Calculated automatically");
                return;
            }
            LocalDate d = tryDate(date.getText());
            nextDue.setText(d == null ? "Enter a valid date" : d.plusDays(availableTypes.get(i - 1).intervalInDays).toString());
        };
        Runnable reloadTypes = () -> {
            int pi = petBox.getSelectedIndex();
            Pet pet = pi > 0 ? myPets.get(pi - 1) : null;
            availableTypes.clear();
            typeBox.removeAllItems();
            typeBox.addItem("Select vaccine");
            for (VaccineType t : sortedTypes()) {
                if (pet == null || t.species.equals(pet.species)) {
                    availableTypes.add(t);
                    typeBox.addItem(t.name + " (" + t.species + ") - every " + t.intervalInDays + " days");
                }
            }
        };
        reloadTypes.run();

        // ----- filters + table -----
        JTextField fPet = new JTextField(9), fBreed = new JTextField(8), fVaccine = new JTextField(9);
        JTextField fFrom = new JTextField(9), fTo = new JTextField(9);
        JComboBox<String> fSpecies = combo("All species", SPECIES);
        JComboBox<String> fStatus = combo("All statuses", STATUSES);
        DefaultTableModel m = model("Pet", "Vaccine", "Date Given", "Next Due Date", "Status");
        JTable t = table(m);
        List<Row> shown = new ArrayList<>();

        Runnable refresh = () -> {
            m.setRowCount(0);
            shown.clear();
            shown.addAll(search(currentUser.id, -1, fPet.getText(), picked(fSpecies), fBreed.getText(), fVaccine.getText(),
                    picked(fStatus), tryDate(fFrom.getText()), tryDate(fTo.getText())));
            for (Row r : shown) {
                m.addRow(new Object[]{r.pet.name, r.type.name, r.vac.dateGiven, r.vac.nextDueDate, statusLabel(r.status)});
            }
        };
        onChange(fPet, refresh);
        onChange(fBreed, refresh);
        onChange(fVaccine, refresh);
        onChange(fFrom, refresh);
        onChange(fTo, refresh);
        fSpecies.addActionListener(e -> refresh.run());
        fStatus.addActionListener(e -> refresh.run());
        refresh.run();

        petBox.addActionListener(e -> {
            reloadTypes.run();
            updateNextDue.run();
        });
        typeBox.addActionListener(e -> updateNextDue.run());
        onChange(date, updateNextDue);

        JButton save = button("Save Vaccination Record", TEAL, e -> {
            int pi = petBox.getSelectedIndex();
            int ti = typeBox.getSelectedIndex();
            try {
                Pet pet = pi > 0 ? myPets.get(pi - 1) : null;
                VaccineType type = ti > 0 ? availableTypes.get(ti - 1) : null;
                addVaccination(pet, type, date.getText(), notes.getText());
                info("Vaccination recorded");
                notes.setText("");
                typeBox.setSelectedIndex(0);
                refresh.run();
            } catch (AppException ex) {
                error(ex.getMessage());
            }
        });
        JButton reset = button("Reset filters", GRAY, e -> {
            fPet.setText("");
            fBreed.setText("");
            fVaccine.setText("");
            fFrom.setText("");
            fTo.setText("");
            fSpecies.setSelectedIndex(0);
            fStatus.setSelectedIndex(0);
        });

        JPanel form = card("Record a vaccination");
        addLeft(form, row(new JLabel("Pet:"), petBox, new JLabel("Vaccine:"), typeBox));
        addLeft(form, row(new JLabel("Date given (yyyy-MM-dd):"), date, new JLabel("Next due date:"), nextDue));
        addLeft(form, row(new JLabel("Notes:"), notes, save));

        JPanel filters = card("Search / filter records");
        addLeft(filters, row(new JLabel("Pet:"), fPet, new JLabel("Species:"), fSpecies, new JLabel("Breed:"), fBreed,
                new JLabel("Vaccine:"), fVaccine));
        addLeft(filters, row(new JLabel("Status:"), fStatus, new JLabel("Given from:"), fFrom, new JLabel("to:"), fTo, reset));

        JPanel top = vbox();
        addLeft(top, heading("Vaccinations"));
        addLeft(top, form);
        addLeft(top, filters);
        page.add(top, BorderLayout.NORTH);
        page.add(new JScrollPane(t), BorderLayout.CENTER);
        page.add(row(button("Delete Selected Record", RED, e -> {
            int r = selectedRow(t);
            if (r < 0) return;
            Row row = shown.get(r);
            if (confirm("Delete the " + row.type.name + " record for " + row.pet.name + "?")) {
                vaccinations.remove(row.vac);
                saveAll();
                refresh.run();
            }
        })), BorderLayout.SOUTH);
        return page;
    }

    // =====================================================================
    //  11. REMINDERS
    // =====================================================================

    static JPanel reminderSection(String title, List<Row> rows) {
        LocalDate today = LocalDate.now();
        DefaultTableModel m = model("Pet", "Vaccine", "Due Date", "When", "Status");
        for (Row r : rows) {
            long days = ChronoUnit.DAYS.between(today, r.vac.nextDueDate);
            String when = days < 0 ? (-days) + " days overdue" : days == 0 ? "today" : "in " + days + " days";
            m.addRow(new Object[]{r.pet.name, r.type.name, r.vac.nextDueDate, when, statusLabel(r.status)});
        }
        JPanel p = new JPanel(new BorderLayout());
        p.setBorder(BorderFactory.createTitledBorder(title + " (" + rows.size() + ")"));
        p.setOpaque(false);
        if (rows.isEmpty()) {
            p.add(new JLabel("  Nothing here."), BorderLayout.CENTER);
        } else {
            p.add(new JScrollPane(table(m)), BorderLayout.CENTER);
        }
        return p;
    }

    static JPanel remindersPage() {
        JPanel page = newPage();
        page.add(heading("Reminders"), BorderLayout.NORTH);
        JPanel sections = new JPanel(new GridLayout(3, 1, 0, 10));
        sections.setOpaque(false);
        sections.add(reminderSection("Overdue", byStatus("OVERDUE")));
        sections.add(reminderSection("Due today", byStatus("DUE_TODAY")));
        sections.add(reminderSection("Due in the next " + UPCOMING_DAYS + " days", byStatus("UPCOMING")));
        page.add(sections, BorderLayout.CENTER);
        return page;
    }

    // =====================================================================
    //  12. VACCINE TYPES
    // =====================================================================

    static JPanel vaccineTypesPage() {
        JPanel page = newPage();
        JTextField name = new JTextField(14);
        JComboBox<String> species = new JComboBox<>(SPECIES);
        JTextField interval = new JTextField(6);
        JTextField description = new JTextField(22);
        VaccineType[] editing = {null}; // the type being edited (null = adding a new one)

        DefaultTableModel m = model("Name", "Species", "Description", "Interval (days)");
        JTable t = table(m);
        List<VaccineType> shown = new ArrayList<>();
        Runnable refresh = () -> {
            m.setRowCount(0);
            shown.clear();
            shown.addAll(sortedTypes());
            for (VaccineType v : shown) {
                m.addRow(new Object[]{v.name, v.species, v.description, v.intervalInDays + " days"});
            }
        };
        refresh.run();

        JButton submit = button("Add Vaccine Type", TEAL, e -> { });
        JButton cancel = button("Cancel edit", GRAY, e -> { });
        cancel.setVisible(false);
        Runnable clearForm = () -> {
            editing[0] = null;
            name.setText("");
            interval.setText("");
            description.setText("");
            species.setSelectedIndex(0);
            submit.setText("Add Vaccine Type");
            cancel.setVisible(false);
        };
        submit.addActionListener(e -> {
            try {
                boolean wasEditing = editing[0] != null;
                saveType(editing[0], name.getText(), (String) species.getSelectedItem(), description.getText(), interval.getText());
                info(wasEditing ? "Vaccine type updated" : "Vaccine type added");
                clearForm.run();
                refresh.run();
            } catch (AppException ex) {
                error(ex.getMessage());
            }
        });
        cancel.addActionListener(e -> clearForm.run());

        JPanel form = card("Add a vaccine type");
        addLeft(form, row(new JLabel("Name:"), name, new JLabel("Species:"), species, new JLabel("Interval (days):"), interval));
        addLeft(form, row(new JLabel("Description:"), description, submit, cancel));

        JPanel top = vbox();
        addLeft(top, heading("Vaccine Types"));
        addLeft(top, form);
        page.add(top, BorderLayout.NORTH);
        page.add(new JScrollPane(t), BorderLayout.CENTER);

        if (isAdmin()) { // only the admin can edit or delete existing types
            page.add(row(
                    button("Edit Selected", ORANGE, e -> {
                        int r = selectedRow(t);
                        if (r < 0) return;
                        VaccineType v = shown.get(r);
                        editing[0] = v;
                        name.setText(v.name);
                        species.setSelectedItem(v.species);
                        interval.setText(String.valueOf(v.intervalInDays));
                        description.setText(v.description);
                        submit.setText("Update Vaccine Type");
                        cancel.setVisible(true);
                    }),
                    button("Delete Selected", RED, e -> {
                        int r = selectedRow(t);
                        if (r < 0) return;
                        VaccineType v = shown.get(r);
                        if (!confirm("Delete vaccine type " + v.name + " (" + v.species + ")?")) return;
                        try {
                            deleteType(v);
                            info("Vaccine type deleted");
                            refresh.run();
                        } catch (AppException ex) {
                            error(ex.getMessage());
                        }
                    })), BorderLayout.SOUTH);
        }
        return page;
    }

    // =====================================================================
    //  13. PROFILE
    // =====================================================================

    static JPanel profilePage() {
        JPanel page = newPage();
        JPanel box = new JPanel(new GridBagLayout());
        box.setBackground(Color.WHITE);
        box.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        formRow(box, 0, "Full name", bold(currentUser.name));
        formRow(box, 1, "Email", bold(currentUser.email));
        formRow(box, 2, "Phone", bold(currentUser.phone.isEmpty() ? "-" : currentUser.phone));
        formRow(box, 3, "Role", bold(currentUser.role));
        JPanel wrap = new JPanel(new FlowLayout(FlowLayout.LEFT));
        wrap.setOpaque(false);
        wrap.add(box);
        page.add(heading("Profile"), BorderLayout.NORTH);
        page.add(wrap, BorderLayout.CENTER);
        return page;
    }

    // =====================================================================
    //  14. ADMIN
    // =====================================================================

    static JPanel adminPage() {
        JPanel page = newPage();

        // statistics
        Map<String, Integer> byStatus = new LinkedHashMap<>();
        Set<Integer> latest = latestIds(vaccinations);
        LocalDate today = LocalDate.now();
        for (Vaccination v : vaccinations) {
            String s = statusOf(v, latest, today);
            byStatus.put(s, byStatus.containsKey(s) ? byStatus.get(s) + 1 : 1);
        }
        Map<String, Integer> bySpecies = new LinkedHashMap<>();
        for (Pet p : pets) {
            bySpecies.put(p.species, bySpecies.containsKey(p.species) ? bySpecies.get(p.species) + 1 : 1);
        }

        JPanel stats = new JPanel(new GridLayout(1, 4, 12, 0));
        stats.setOpaque(false);
        stats.add(statCard("Total Users", owners.size(), BLUE));
        stats.add(statCard("Total Pets", pets.size(), TEAL));
        stats.add(statCard("Total Vaccinations", vaccinations.size(), ORANGE));
        stats.add(statCard("Vaccine Types", types.size(), RED));

        JPanel top = vbox();
        addLeft(top, row(heading("Admin Dashboard"), button("Manage vaccine types", BLUE, e -> go("Vaccine Types"))));
        addLeft(top, stats);
        addLeft(top, new JLabel("  Vaccinations by status: " + (byStatus.isEmpty() ? "none" : byStatus.toString().replace("_", " "))));
        addLeft(top, new JLabel("  Pets by species: " + (bySpecies.isEmpty() ? "none" : bySpecies.toString())));
        page.add(top, BorderLayout.NORTH);

        // users tab
        DefaultTableModel um = model("Name", "Email", "Phone", "Role");
        for (Owner o : owners) {
            um.addRow(new Object[]{o.name, o.email, o.phone, o.role});
        }
        JTable ut = table(um);
        JPanel usersTab = new JPanel(new BorderLayout());
        usersTab.add(new JScrollPane(ut), BorderLayout.CENTER);
        usersTab.add(row(button("Delete User", RED, e -> {
            int r = selectedRow(ut);
            if (r < 0) return;
            Owner o = owners.get(r);
            if (!confirm("Delete " + o.name + "? This also removes their pets and vaccination records.")) return;
            try {
                deleteUser(o);
                go("Admin");
            } catch (AppException ex) {
                error(ex.getMessage());
            }
        })), BorderLayout.SOUTH);

        // pets tab
        DefaultTableModel pm = model("Name", "Species", "Breed", "Owner", "Status");
        for (Pet p : pets) {
            pm.addRow(new Object[]{p.name, p.species, p.breed, findOwner(p.ownerId).name, statusLabel(petStatus(p.id))});
        }
        JTable pt = table(pm);
        JPanel petsTab = new JPanel(new BorderLayout());
        petsTab.add(new JScrollPane(pt), BorderLayout.CENTER);
        petsTab.add(row(button("Delete Pet", RED, e -> {
            int r = selectedRow(pt);
            if (r < 0) return;
            Pet p = pets.get(r);
            if (confirm("Delete " + p.name + "? This also removes its vaccination records.")) {
                deletePet(p);
                go("Admin");
            }
        })), BorderLayout.SOUTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Users", usersTab);
        tabs.addTab("Pets", petsTab);
        page.add(tabs, BorderLayout.CENTER);
        return page;
    }

    // =====================================================================
    //  15. START THE PROGRAM
    // =====================================================================

    public static void main(String[] args) {
        loadAll();
        seedDefaults();
        printReminders();

        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
            } catch (Exception e) {
                // the default look is fine
            }
            frame = new JFrame("PetCareBook - Pet Vaccination Reminder");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(1150, 720);
            frame.setLocationRelativeTo(null);
            showLogin();
            frame.setVisible(true);
        });
    }
}
