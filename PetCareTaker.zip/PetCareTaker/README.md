# PetCareTaker - Pet Vaccination Reminder (simple Java version)

One Java file, no Maven, no database, no npm, no frontend/backend split.

## How to run in IntelliJ IDEA
1. File > Open > select this `PetCareTaker` folder.
2. If IntelliJ asks for an SDK, choose any JDK 17 or newer
   (File > Project Structure > Project > SDK).
3. Open `src/PetCareTaker.java` and click the green run arrow next to `main`
   (or pick the "PetCareTaker" run configuration at the top right).

Default admin login: `admin@petcarebook.com` / `Admin@123`

## Where is my data?
Saved as plain text files in a `data` folder that is created next to `src`
the first time you run. Delete that folder to start fresh.

## Features (all kept from the original project)
- Register / login / logout, Admin and User roles (passwords stored hashed)
- Home dashboard: total pets, total vaccinations, upcoming (7 days), overdue, "Needs attention" list
- My Pets: add, edit, delete, view profile, search by name / species / breed, vaccination status
- Vaccination history for each pet
- Vaccinations: record a vaccination (next due date is calculated automatically),
  filter by pet, species, breed, vaccine, status and date range, delete records
- Reminders: overdue, due today, due in the next 7 days (also printed in the console
  and shown in a pop-up after login - replaces the old daily scheduler)
- Vaccine Types: everyone can add; admin can edit and delete
- Profile page
- Admin dashboard: statistics, all users, all pets, delete users / pets
- Same rules as before: vaccine must match the pet's species, no future dates,
  no date before birth, no duplicate records, species locked once records exist,
  used vaccine types cannot be deleted, admin cannot delete themselves
